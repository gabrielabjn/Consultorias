library(data.table)
library(dplyr)
library(DescTools) # para SIGN.test
library(rstatix)   # para symmetry.test (se preferir)


rodar_testes <- function(dt, var_base, var_2) {
  x1 <- as.numeric(dt[[var_base]])
  x2 <- as.numeric(dt[[var_2]])
  
  idx <- !is.na(x1) & !is.na(x2)
  x1 <- x1[idx]
  x2 <- x2[idx]
  
  dif <- x1 - x2
  
  get_pvalue <- function(test_obj) {
    if (is.null(test_obj)) return(NA)
    pval <- tryCatch({
      test_obj$p.value
    }, error = function(e) NA)
    if (length(pval) != 1 || is.na(pval)) return(NA)
    return(pval)
  }
  
  simetria <- tryCatch(symmetry.test(dif), error = function(e) NULL)
  sinal <- tryCatch(SIGN.test(x1, x2, alternative = "two.sided"), error = function(e) NULL)
  wilcox <- tryCatch(wilcox.test(x1, x2, paired = TRUE), error = function(e) NULL)
  ttest <- tryCatch(t.test(x1, x2, paired = TRUE), error = function(e) NULL)
  
  list(
    simetria = get_pvalue(simetria),
    sinal_pvalor = get_pvalue(sinal),
    wilcox_pvalor = get_pvalue(wilcox),
    ttest_pvalor = get_pvalue(ttest)
  )
}
# Variáveis que deseja testar
variaveis <- c("alerta", "envergonhado", "inspirado", "nervoso", "determinado",
               "atento", "ansioso", "ativo", "medo")

# Para cada variável, o nome da variável 2 no pós-experimento
variaveis_2 <- paste0(toupper(variaveis),"2")

# Aplicar para homens
resultados_homens <- lapply(seq_along(variaveis), function(i) {
  rodar_testes(dt_m, variaveis[i], variaveis_2[i])
})
names(resultados_homens) <- variaveis

# Aplicar para mulheres
resultados_mulheres <- lapply(seq_along(variaveis), function(i) {
  rodar_testes(dt_f, variaveis[i], variaveis_2[i])
})
names(resultados_mulheres) <- variaveis

# Resultado exemplo
resultados_homens
resultados_mulheres